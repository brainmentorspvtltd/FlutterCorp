import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import '/utils/toast.dart';

detectNetwork(Function fn) {
  StreamSubscription sub =
      Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
    // Got a new connectivity status!
    if (result == ConnectivityResult.mobile ||
        result == ConnectivityResult.wifi) {
      // Online
      fn(true);
      showToastMessage("Online");
    } else if (result == ConnectivityResult.none) {
      // Offline
      fn(false);
      showToastMessage("Offline");
    }
  });
  return sub;
}
