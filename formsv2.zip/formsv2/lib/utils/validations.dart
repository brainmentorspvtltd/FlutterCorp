class Validation {
  int minLength = 3;
  setMinLength(int min) {
    minLength = min;
  }

  bool isCorrectEmail(String email) {
    return email.length > 0;
  }

  bool isMin(String value) {
    return value.length >= minLength;
  }

  bool isMax(String value, int maxLength) {
    return value.length < maxLength;
  }

  bool isValidName(String name) {
    // if (name.length == 0) {
    //   return false;
    // }
    // if (!isMin(name, 3)) {
    //   return false;
    // }
    // if (!isMax(name, 10)) {
    //   return false;
    // }
    setMinLength(3);
    return name.length > 0 && isMin(name) && isMax(name, 10);
  }
}
