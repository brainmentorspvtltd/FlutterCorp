import 'package:flutter/material.dart';

import '../models/user.dart';

class RegFormField extends StatelessWidget {
  String label;
  Function validationFn;
  bool hideText;
  Function changeFn;
  String errorMessage;
  User model;
  RegFormField(
      {required this.label,
      required this.validationFn,
      this.hideText = false,
      required this.changeFn,
      required this.errorMessage,
      required this.model});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      child: TextFormField(
        onChanged: (String value) {
          changeFn(value);
        },
        obscureText: hideText,
        onSaved: (String? value) {
          print("ON Saved Call $value   ::: $label");
          String lbl = label.toLowerCase();
          if (lbl == "email") {
            model.email = value;
          } else if (lbl == "name") {
            model.name = value;
          } else if (lbl == "password") {
            model.password = value;
          }
        },
        validator: (String? value) {
          if (validationFn(value)) {
            return null; // No Error Message
          } else {
            return "Invalid $label !"; // Error Message will be printed
          }
        },
        decoration: InputDecoration(
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30),
            ),
            errorText: errorMessage,
            // errorBorder: OutlineInputBorder(borderSide: BorderSide.),
            errorStyle: TextStyle(
                fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blue),
            hintText: 'Type $label',
            label: Text(label),
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
      ),
    );
  }
}
