import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:workingonforms/repository/offline.dart';
import '../models/user.dart';
import '../utils/network.dart';
import '../utils/toast.dart';
import '/utils/validations.dart';
import '/widgets/form_field.dart';

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  Validation _validation = Validation();
  String passwordError = "";
  String nameError = "";
  String emailError = "";
  late User _user = User();
  late StreamSubscription subscription;

  _passwordValidateOnChange(String value) {
    if (value.length > 0 && value.length <= 7) {
      passwordError = "Wrong Password !";
    } else {
      passwordError = "";
    }
    setState(() {}); // Rebuild UI
  }

  _nameValidateOnChange(String value) {
    if (value.length <= 2) {
      nameError = "Name is Too Short";
    } else {
      nameError = "";
    }
    setState(() {});
  }

  _emailValidateOnChange(String value) {
    if (value.length == 0) {
      emailError = "Email Requried...";
    }
    setState(() {});
  }

  _onlineSaveTheData() {
    print("Online Save Call");
  }

  Offline offline = Offline();
  _offLineSaveTheData() async {
    print("Offline Save Call");

    String message = "";
    try {
      message = await offline.storeDataInBox(_user);
    } catch (err) {
      message = "Some Problem in Save Offline";
    }
    showToastMessage(message);
    print("Data Rec $offline.getDataFromBox()");
  }

  _submitForm() {
    var formState = formKey.currentState;
    if (formState != null && formState.validate()) {
      formState.save();
      // Save Online or Offline
      if (flag) {
        _onlineSaveTheData();
      } else {
        _offLineSaveTheData();
      }
      print("User Object is $_user");
      print("Form is Valid");
    } else {
      print("Form is Not valid");
    }
  }

  bool flag = true; // Online
  getOnlineOffLineFlag(bool flag) {
    this.flag = flag;
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    subscription = detectNetwork(getOnlineOffLineFlag);
  }

  final formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text('Register'),
          centerTitle: true,
          leading: Icon(Icons.app_registration_rounded)),
      body: SafeArea(
          child: Form(
        //autovalidateMode: AutovalidateMode.always,
        key: formKey,
        child: Column(
          children: [
            RegFormField(
              model: _user,
              errorMessage: emailError,
              changeFn: _emailValidateOnChange,
              label: 'Email',
              validationFn: _validation.isCorrectEmail,
            ),
            RegFormField(
              model: _user,
              errorMessage: passwordError,
              changeFn: _passwordValidateOnChange,
              label: 'Password',
              hideText: true,
              validationFn: (String str) {
                _validation.setMinLength(8);
                return _validation.isMin(str);
              },
            ),
            RegFormField(
              model: _user,
              errorMessage: nameError,
              changeFn: _nameValidateOnChange,
              label: 'Name',
              validationFn: _validation.isValidName,
            ),
            ElevatedButton(
                onPressed: () {
                  _submitForm();
                },
                child: Text('Register'))
          ],
        ),
      )),
    );
  }
}
