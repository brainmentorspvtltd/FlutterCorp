import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import './pages/register.dart';

void main() async {
  await Hive.initFlutter(); // Block
  runApp(MaterialApp(
    home: Register(),
  ));
}
