class User {
  late String _email;
  late String _password;
  late String _name;
  get email => this._email;

  set email(value) => this._email = value;

  get password => this._password;

  set password(value) => this._password = value;

  get name => this._name;

  set name(value) => this._name = value;
  User() {} // Default Constructor
  User.takeInput(String email, String password, String name) {
    this._email = email;
    this._password = password;
    this._name = name;
  }
  @override
  String toString() {
    return "Email $email Name $name Password $password";
  }
}
