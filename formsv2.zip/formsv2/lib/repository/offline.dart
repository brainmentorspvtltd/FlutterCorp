import 'package:hive_flutter/hive_flutter.dart';

import '../models/user.dart';

class Offline {
  late Box box;
  _createBox() async {
    box = await Hive.openBox('users');
  }

  Offline() {
    _createBox();
  }

  storeDataInBox(User user) async {
    try {
      await box.put('mydata', user);
      return "Record Saved...";
    } catch (e) {
      print(e);
      return "Error in Saved...";
    }
  }

  User getDataFromBox() {
    return box.get('mydata');
  }
}
