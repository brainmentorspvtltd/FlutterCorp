import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class RowAndCol extends StatelessWidget {
  const RowAndCol({Key? key}) : super(key: key);

  _getContainer(
      {Color color = Colors.redAccent,
      double width = 100,
      double height = 100}) {
    return Container(
      width: width,
      height: height,
      color: color,
    );
  }

  Text _getText({String msg = "Hi", double fontSize = 20}) {
    return Text(
      msg,
      style: TextStyle(fontSize: fontSize),
    );
  }

  _getIcon(iconName) {
    return IconButton(
      onPressed: () {},
      icon: FaIcon(iconName),
      color: Colors.red,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.end,
        //crossAxisAlignment: CrossAxisAlignment.baseline,
        // textBaseline: TextBaseline.ideographic,
        // textDirection: TextDirection.rtl,
        // crossAxisAlignment: CrossAxisAlignment.baseline,
        children: [
          // _getText(msg: "你好", fontSize: 40),
          // _getText(),
          // _getText(msg: "যালো", fontSize: 30)
          _getIcon(FontAwesomeIcons.camera),
          _getIcon(FontAwesomeIcons.play),
          Icon(Icons.camera)
          // _getContainer(width: 150, height: 200),
          // _getContainer(color: Colors.green),
          // _getContainer(color: Colors.blue, width: 50, height: 50)
        ],
      ),
    ));
  }
}
