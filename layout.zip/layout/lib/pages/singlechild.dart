import 'package:flutter/material.dart';

class SingleChild extends StatelessWidget {
  const SingleChild({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Container(
              margin: EdgeInsets.only(top: 400),
              //color: Colors.red,
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: Colors.black, blurRadius: 30)],
                  // borderRadius: BorderRadius.circular(20),
                  //color: Colors.redAccent,
                  gradient: LinearGradient(colors: [
                    Colors.redAccent,
                    Colors.yellowAccent,
                    Colors.orangeAccent
                  ], begin: Alignment.topLeft, end: Alignment.bottomRight),
                  border: Border.all(width: 5, color: Colors.green)),
              width: 400,
              height: 400,
              child: Center(
                child: Text(
                  'Hello Flutter',
                  style: TextStyle(fontSize: 40),
                ),
              )),
        ),
      ),
    );
  }
}
