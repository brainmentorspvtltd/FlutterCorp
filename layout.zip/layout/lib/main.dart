import 'package:flutter/material.dart';
import './pages/rowandcol.dart';
import './pages/singlechild.dart';

void main() {
  runApp(MaterialApp(home: RowAndCol()));
}
