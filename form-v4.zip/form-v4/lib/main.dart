import 'package:flutter/material.dart';
import 'package:flutter_form_handling/pages/viewall.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '/pages/register.dart';
import 'models/person.dart';

void main() async {
  // Step-1 Initalize the Hive
  await Hive.initFlutter();
  Hive.registerAdapter(PersonAdapter());
  //runApp(MaterialApp(home: Register()));
  runApp(MaterialApp(home: ViewAll()));
}
