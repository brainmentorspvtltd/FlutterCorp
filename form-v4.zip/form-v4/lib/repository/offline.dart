import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../models/person.dart';

class Offline {
  // CRUD
  late Box box;
  Offline() {
    openBox('personbox');
  }
  openBox(String boxName) async {
    box = await Hive.openBox(boxName);
  }

  closeBox() {
    box.close();
  }

  ValueListenable<Box> readAll() {
    return box.listenable();
  }

  Future<String> addPerson(Person person) async {
    try {
      await box.add(person);
      return "Record is Added";
    } catch (err) {
      print("Error During Add $err");
    }
    return "Error During Add";
  }
}
