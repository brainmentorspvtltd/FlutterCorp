import 'package:flutter/material.dart';
import 'package:flutter_form_handling/repository/offline.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../models/person.dart';

class ViewAll extends StatefulWidget {
  Offline _offline = Offline();

  @override
  State<ViewAll> createState() => _ViewAllState();
}

class _ViewAllState extends State<ViewAll> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Read All Records')),
      body: ValueListenableBuilder<Box>(
        valueListenable: widget._offline.readAll(),
        builder: (context, Box box, widget) {
          if (box == null || box.isEmpty) {
            return Center(child: Text('No Records !'));
          } else {
            return ListView.builder(
              itemCount: box.length,
              itemBuilder: (_, int index) {
                Person person = box.get(index);
                return ListTile(
                  leading: Icon(Icons.person),
                  title: Text(person.name),
                  subtitle: Text(person.email + " , " + person.city),
                );
              },
            );
          }
        },
      ),
    );
  }
}
