import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class CustomDatePicker extends StatefulWidget {
  const CustomDatePicker({Key? key}) : super(key: key);

  @override
  State<CustomDatePicker> createState() => _CustomDatePickerState();
}

class _CustomDatePickerState extends State<CustomDatePicker> {
  TextEditingController tc = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(20),
      child: TextField(
        controller: tc,
        readOnly: true,
        onTap: () async {
          DateTime? pickDate = await showDatePicker(
              context: context,
              initialDate: DateTime.now(),
              firstDate: DateTime(1947),
              lastDate: DateTime(2050));
          if (pickDate != null) {
            String formattedDate = DateFormat('yyyy-MM-dd').format(pickDate);
            tc.text = formattedDate;
          }
        },
        decoration: InputDecoration(
            suffixIcon: Icon(Icons.calendar_today),
            //icon: Icon(Icons.calendar_today),
            labelText: "Enter Date"),
      ),
    );
  }
}
