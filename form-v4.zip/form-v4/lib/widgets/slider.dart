import 'package:flutter/material.dart';

class CustomSlider extends StatefulWidget {
  const CustomSlider({Key? key}) : super(key: key);

  @override
  State<CustomSlider> createState() => _CustomSliderState();
}

class _CustomSliderState extends State<CustomSlider> {
  //double _currentValue = 0.0;
  double startValue = 0.0;
  double endValue = 10.0;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: RangeSlider(
        onChangeStart: (val) {},
        onChangeEnd: (val) {},
        labels: RangeLabels(
            startValue.round().toString(), endValue.round().toString()),
        activeColor: Colors.amberAccent,
        //thumbColor: Colors.black,
        inactiveColor: Colors.grey,
        min: 0.0,
        max: 100.0,
        divisions: 10,
        values: RangeValues(startValue, endValue),
        //value: _currentValue,
        onChanged: (RangeValues values) {
          startValue = values.start;
          endValue = values.end;
          setState(() {});
        },
        // onChanged: (double value) {
        //   _currentValue = value;
        //   setState(() {});
        // },
      ),
    );
  }
}
