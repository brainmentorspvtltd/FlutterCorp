class Validation {
  Validation._() {}
  static String? isCorrectEmail(String email) {
    if (email.trim().length == 0) {
      return "Email Can't be Blank !";
    } else if (!email.contains("@")) {
      return "Invalid Email !";
    } else if (!(email.endsWith(".com") || email.endsWith(".in"))) {
      return "Invalid Email !";
    }
    return null;
  }

  static String? isCorrectPassword(String password) {
    if (password.length <= 7) {
      return "Invalid Password !";
    }
    return null;
  }

  static String? isCorrectName(String password) {
    if (password.length <= 2) {
      return "Invalid Name !";
    }
    return null;
  }
}
