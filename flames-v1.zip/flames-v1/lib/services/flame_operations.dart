class FlameOperations {
  /*
  Remove common chars and return the count of
  remaining characters
  */
  Map<String, int> map = {};
  List<String> flames_str = ["F", "L", "A", "M", "E", "S"];

  String getRelationShip(String maleName, String femaleName) {
    int count = _getCountofRemainingChars(maleName, femaleName);
    // Get the First Time Position to Remove
    // To get the Position int position = count % flames_str.length
    while (flames_str.length != 1) {
      // remove the character at position-1 (index)
      // after remove the newposition is at the removed index place
      // Now get the position = (count % flames_str.length ) + newposition
    }
    return flames_str[0]; // At the end we return the name of the relationship
  }

  void _getMap(String name, bool isPlus) {
    List<String> list = name.split(""); // String convert into List of String
    //List represent single chars
    for (String key in list) {
      if (map.containsKey(key)) {
        // Key is Present in the map
        int value = map[key]!;
        map[key] = isPlus ? ++value : --value;
      } else {
        map[key] = isPlus ? 1 : -1;
      }
    }
  }

  int _getCountofRemainingChars(String maleName, String femaleName) {
    _getMap(maleName, true);
    _getMap(femaleName, false);
    int count = 0;
    for (String key in map.keys) {
      int value = map[key]!;
      value = value.abs();
      if (value > 0) {
        count = count + value;
      }
    }
    return count;
  }
}
