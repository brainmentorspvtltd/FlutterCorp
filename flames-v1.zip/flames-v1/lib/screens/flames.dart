import 'package:flames_app/services/flame_operations.dart';
import 'package:flames_app/widgets/button.dart';
import 'package:flames_app/widgets/output.dart';
import 'package:flames_app/widgets/textbox.dart';
import 'package:flutter/material.dart';

class FlamesScreen extends StatefulWidget {
  const FlamesScreen({Key? key}) : super(key: key);

  @override
  State<FlamesScreen> createState() => _FlamesScreenState();
}

class _FlamesScreenState extends State<FlamesScreen> {
  FlameOperations opr = FlameOperations();
  String nameOfTheRelationShip = "";
  TextEditingController ctrl1 =
      TextEditingController(); // Pull the TextField Value (Set , Get)
  TextEditingController ctrl2 =
      TextEditingController(); // Pull the TextField Value (Set , Get)

  _clearAll() {
    ctrl1.text = "";
    ctrl2.text = "";
  }

  _showRelationShip() {
    String maleName = ctrl1.text;
    String femaleName = ctrl2.text;
    String relationShipName = opr.getRelationShip(maleName, femaleName);
    print("RelationShip Name $relationShipName");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Flames App'),
      ),
      body: Container(
          child: Column(
        children: [
          TextBox(label: 'Male', icon: Icons.male, tc: ctrl1),
          TextBox(label: 'Female', icon: Icons.female, tc: ctrl2),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Button(
                  label: 'RelationShip',
                  color: Colors.black,
                  fn: _showRelationShip),
              Button(label: 'Clear All', fn: _clearAll)
            ],
          ),
          Output(nameOfTheRelationShip)
        ],
      )),
    );
  }
}
