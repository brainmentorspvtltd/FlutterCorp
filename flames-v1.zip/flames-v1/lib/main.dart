import 'package:flames_app/screens/flames.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: FlamesScreen()));
}
