import 'package:flutter/material.dart';

class Button extends StatelessWidget {
  String label;
  Color color;
  Function fn;
  Button(
      {required this.label, this.color = Colors.redAccent, required this.fn});

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.all(10),
        child: ElevatedButton(
          style: ButtonStyle(backgroundColor: MaterialStateProperty.all(color)),
          child: Text(label),
          onPressed: () {
            fn();
          },
        ));
  }
}
