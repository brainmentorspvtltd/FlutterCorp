import 'package:flutter/material.dart';

class TextBox extends StatelessWidget {
  String label;
  IconData icon;
  TextEditingController tc;
  TextBox({required this.label, required this.icon, required this.tc});

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.all(10),
        child: TextField(
          controller: tc,
          style: TextStyle(fontSize: 30),
          decoration: InputDecoration(
              prefixIcon: Icon(icon, size: 40),
              label: Text(label),
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(20))),
        ));
  }
}
