import 'package:flutter/material.dart';

class SearchBox extends StatelessWidget {
  const SearchBox({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      decoration: BoxDecoration(
          //  borderRadius: BorderRadius.circular(10),
          //border: Border.all(color: Colors.grey.shade300, width: 2),
          color: Colors.grey.shade300),
      // padding: EdgeInsets.all(10),
      child: TextField(
        decoration: InputDecoration(
            border: InputBorder.none,
            // border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
            hintText: 'Search for Products',
            prefixIcon: Icon(Icons.search)),
      ),
    );
  }
}
