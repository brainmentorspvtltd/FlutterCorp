import '../models/item_model.dart';

class ItemRepo {
  //Challenge-4 Get Items talk to the BackEnd API (RestFul API) and bring the data
  List<ItemModel> getItems() {
    return [
      ItemModel("Olive Oil",
          'https://www.bigbasket.com/media/uploads/p/xxl/40061618_3-olitalia-100-pure-olive-oil.jpg'),
      ItemModel("Organic",
          'https://5.imimg.com/data5/VF/CT/MY-49857352/organic-vegetables-500x500.png'),
      ItemModel("Chia Seeds",
          'https://www.bigbasket.com/media/uploads/p/xxl/40100577_6-bb-royal-organic-chia-seeds.jpg'),
    ];
  }
}
