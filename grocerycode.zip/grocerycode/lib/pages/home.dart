import 'package:flutter/material.dart';
import '../widgets/grid.dart';
import '../widgets/grocery_appbar.dart';
import '../widgets/search.dart';
import '../widgets/banner.dart' as mybanner;

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          child: GroceryAppBar(), preferredSize: Size.fromHeight(70)),
      body: Column(children: [SearchBox(), mybanner.Banner(), Grid()]),
    );
  }
}
