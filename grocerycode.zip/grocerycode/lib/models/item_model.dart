class ItemModel {
  String name;
  String url;
  ItemModel(this.name, this.url);
  // Challenge-3
  // Data Will be come from BackEnd (Model to JSON and JSON to Model Conversion)
}
