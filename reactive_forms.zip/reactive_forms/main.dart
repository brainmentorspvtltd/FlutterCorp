import 'package:flutter/material.dart';
import 'package:forms_demo/pages/login.dart';

void main() {
  runApp(MaterialApp(
    home: Login(),
  ));
}
