import 'package:flutter/material.dart';
import 'package:reactive_forms/reactive_forms.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  late FormGroup form;
  _createForm() {
    // Create Model of a Form
    form = FormGroup({
      'email': FormControl<String>(
          //touched: true,
          value: '',
          asyncValidators: [_emailUniqueCheck],
          validators: [Validators.required, Validators.email]),
      'password': FormControl<String>(
          value: '', validators: [Validators.required, _pwdCheck]),
      'address': FormArray<String>([])
    });
  }

  final List<String> emails = ['amit@yahoo.com', 'ram@yahoo.com'];
  Future<Map<String, dynamic>?> _emailUniqueCheck(
      AbstractControl<dynamic> ctrl) async {
    bool result = await Future<bool>.delayed(Duration(seconds: 10), () {
      return emails.indexOf(ctrl.value) >= 0;
    });
    if (result) {
      ctrl.markAsTouched();
      return {"dupemail": true};
    } else {
      return null;
    }
  }

  Map<String, dynamic>? _pwdCheck(AbstractControl<dynamic> ctrl) {
    return ctrl.isNotNull &&
            ctrl.value.toString().length >= 8 &&
            ctrl.value.toString().length <= 25
        ? null
        : {'invalidpwd': true};
  }

  _submit() {
    if (form.valid) {
      print(form.control('email').value);
      print(form.control('password').value);
    } else {
      form.markAllAsTouched();
      print("Form is Invalid");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _createForm();
  }

  _addAddress() {
    FormArray<String> addressArr = form.control('address') as FormArray<String>;
    addressArr.add(FormControl<String>(
      value: '',
    ));
    setState(() {});
  }

  int index = 0;
  _showDyamicFields() {
    if (form == null) {
      _createForm();
    }
    FormArray<String> addressArr = form.control('address') as FormArray<String>;

    List<Widget> l = addressArr.controls.map((AbstractControl ctrl) {
      return ReactiveTextField(
        formControlName: ctrl.value,
      );
    }).toList();
    return l;
  }

  @override
  Widget build(BuildContext context) {
    return ReactiveFormConfig(
      validationMessages: {
        ValidationMessage.required: (error) => 'Field cannot be Empty',
        ValidationMessage.email: (error) => 'Email is Invalid'
      },
      child: Scaffold(
        body: SafeArea(
            child: ReactiveForm(
          formGroup: form,
          child: Column(
            children: [
              ReactiveTextField(
                formControlName: 'email',
                validationMessages: {
                  ValidationMessage.required: (err) => 'Email is Empty',
                  'dupemail': (err) => 'Duplicate Email '
                  // ValidationMessage.email: (err) => 'Email is Invalid'
                },
                decoration: InputDecoration(
                    hintText: 'Email', border: OutlineInputBorder()),
              ),
              ReactiveTextField(
                validationMessages: {
                  'invalidpwd': (err) => 'Invalid Password !'
                  //  ValidationMessage.required: (err) => 'Password is Empty',
                },
                obscureText: true,
                formControlName: 'password',
                decoration: InputDecoration(
                    hintText: 'Password', border: OutlineInputBorder()),
              ),
              ElevatedButton(
                  onPressed: () {
                    _submit();
                  },
                  child: Text('Login')),
              ElevatedButton(
                  onPressed: () {
                    _addAddress();
                  },
                  child: Text('Add Address')),
              // Display Dynamic Fields
              Column(
                children: _showDyamicFields(),
              )
            ],
          ),
        )),
      ),
    );
  }
}
