import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Output extends StatelessWidget {
  String nameOfTheRelationShip;
  Output(this.nameOfTheRelationShip);

  @override
  Widget build(BuildContext context) {
    return Container(
        child: Text(
      nameOfTheRelationShip,
      style: GoogleFonts.pacifico(color: Colors.purple, fontSize: 40),
    ));
  }
}
