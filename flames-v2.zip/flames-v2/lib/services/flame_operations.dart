class FlameOperations {
  /*
  Remove common chars and return the count of
  remaining characters
  */
  Map<String, int> map = {};
  List<String> flames_str = ["F", "L", "A", "M", "E", "S"];
  Map<String, String> flameMap = {
    "F": "Friend",
    "L": "Love",
    "A": "Affication",
    "M": "Marriage",
    "E": "Enemy",
    "S": "Sister"
  };

  String getRelationShip(String maleName, String femaleName) {
    int count = _getCountofRemainingChars(maleName, femaleName);
    // Write Logic for Remove Flame Characters
    // Get the First Time Position to Remove
    // To get the Position int position = count % flames_str.length
    int flameRange;
    int nextPos = 0;
    while (flames_str.length > 1) {
      // Settle Down the Range
      flameRange = count % flames_str.length;
      flameRange = (flameRange + nextPos);
      // If flameRange goes out of range
      if (flameRange > flames_str.length) {
        flameRange = flameRange % flames_str.length;
      }
      if (flameRange == 0) {
        flames_str.removeAt(flames_str.length - 1); // Remove the Last Character
        continue;
      }
      // if flameRange is not zero
      flames_str.removeAt(flameRange - 1); // pos -1 = index
      if (flameRange >= 1) {
        nextPos = flameRange - 1;
      }
    }
    String relationShipChar =
        flames_str[0]; // At the end we return the name of the relationship
    return flameMap[relationShipChar]!;
  }

  void _getMap(String name, bool isPlus) {
    List<String> list = name.split(""); // String convert into List of String
    //List represent single chars
    for (String key in list) {
      if (map.containsKey(key)) {
        // Key is Present in the map
        int value = map[key]!;
        map[key] = isPlus ? ++value : --value;
      } else {
        map[key] = isPlus ? 1 : -1;
      }
    }
  }

  int _getCountofRemainingChars(String maleName, String femaleName) {
    _getMap(maleName, true);
    _getMap(femaleName, false);
    int count = 0;
    for (String key in map.keys) {
      int value = map[key]!;
      value = value.abs();
      if (value > 0) {
        count = count + value;
      }
    }
    return count;
  }
}
