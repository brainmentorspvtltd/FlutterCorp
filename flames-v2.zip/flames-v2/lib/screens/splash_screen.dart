import 'package:flames_app/screens/flames.dart';
import 'package:flutter/material.dart';

import 'package:google_fonts/google_fonts.dart';
import 'package:video_player/video_player.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  late VideoPlayerController _controller;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = VideoPlayerController.network(
        'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4')
      ..initialize().then((_) {
        _controller.setLooping(true);
        _controller.play();
        // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
        setState(() {});
        _timer();
      });
  }

  void _timer() {
    Future.delayed(Duration(seconds: 19), _moveToNextScreen);
  }

  void _moveToNextScreen() {
    Navigator.of(context)
        .pushReplacement(MaterialPageRoute(builder: (_) => FlamesScreen()));
  }

  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    return Scaffold(
      body: SafeArea(
        child: Stack(fit: StackFit.expand, children: [
          _controller.value.isInitialized
              ? AspectRatio(
                  aspectRatio: _controller.value.aspectRatio,
                  child: VideoPlayer(_controller),
                )
              : Container(),
          Positioned(
              top: deviceSize.height / 2,
              left: deviceSize.width * 0.10,
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.handshake,
                        color: Colors.white,
                        size: 40,
                      ),
                      Text(
                        'Flames App',
                        style: GoogleFonts.pacifico(
                            color: Colors.redAccent, fontSize: 50),
                      ),
                    ],
                  ),
                  Text(
                    'Brain Mentors Pvt Ltd',
                    style: GoogleFonts.roboto(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ))
        ]),
      ),
    );
  }
}
