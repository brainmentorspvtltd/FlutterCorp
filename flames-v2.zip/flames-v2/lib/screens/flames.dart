import 'package:flames_app/services/flame_operations.dart';
import 'package:flames_app/widgets/button.dart';
import 'package:flames_app/widgets/output.dart';
import 'package:flames_app/widgets/textbox.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class FlamesScreen extends StatefulWidget {
  const FlamesScreen({Key? key}) : super(key: key);

  @override
  State<FlamesScreen> createState() => _FlamesScreenState();
}

class _FlamesScreenState extends State<FlamesScreen> {
  FlameOperations opr = FlameOperations();
  String nameOfTheRelationShip = "";
  TextEditingController ctrl1 =
      TextEditingController(); // Pull the TextField Value (Set , Get)
  TextEditingController ctrl2 =
      TextEditingController(); // Pull the TextField Value (Set , Get)
  TextEditingController ctrl3 = TextEditingController();
  _clearAll() {
    ctrl1.text = "";
    ctrl2.text = "";
  }

  _showRelationShip() {
    String maleName = ctrl1.text;
    String femaleName = ctrl2.text;
    String relationShipName = opr.getRelationShip(maleName, femaleName);
    print("RelationShip Name $relationShipName");
    ctrl3.text = relationShipName;
    nameOfTheRelationShip = relationShipName;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(
          Icons.handshake,
          size: 50,
        ),
        backgroundColor: Colors.deepOrangeAccent,
        centerTitle: true,
        title: Text(
          'Flames APP',
          style: GoogleFonts.pacifico(fontSize: 30, color: Colors.black),
        ),
      ),
      body: Container(
          child: Column(
        children: [
          TextBox(label: 'Male', icon: Icons.male, tc: ctrl1),
          TextBox(label: 'Female', icon: Icons.female, tc: ctrl2),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Button(
                  label: 'RelationShip',
                  color: Colors.black,
                  fn: _showRelationShip),
              Button(label: 'Clear All', fn: _clearAll)
            ],
          ),
          //TextBox(label: 'RelationShip', icon: Icons.handshake, tc: ctrl3),
          Output(nameOfTheRelationShip)
        ],
      )),
    );
  }
}
