class DropDownOperations {
  // Private Named Constructor
  DropDownOperations._() {}
  static List<String> getCityData() {
    // Assume API Calls
    // But we put some hardcoded data for now
    List<String> cities = ["Delhi", "Mumbai", "Chennai"];
    return cities;
  }
}
