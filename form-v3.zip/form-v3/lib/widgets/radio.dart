import 'package:flutter/material.dart';

class Radio extends StatefulWidget {
  const Radio({Key? key}) : super(key: key);

  @override
  State<Radio> createState() => _RadioState();
}

class _RadioState extends State<Radio> {
  int groupValue = -1;
  _genderValueChange(int? val) {
    print("Gender value $val");
    groupValue = val!;

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(children: [
        Expanded(
          child: RadioListTile(
              value: 1,
              title: Text('Male'),
              groupValue: groupValue,
              onChanged: _genderValueChange),
        ),
        Expanded(
          child: RadioListTile(
              value: 2,
              title: Text('Female'),
              groupValue: groupValue,
              onChanged: _genderValueChange),
        )
      ]),
    );
  }
}
