import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class CustomTimePicker extends StatefulWidget {
  const CustomTimePicker({Key? key}) : super(key: key);

  @override
  State<CustomTimePicker> createState() => _CustomTimePickerState();
}

class _CustomTimePickerState extends State<CustomTimePicker> {
  TextEditingController tc = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(20),
      child: TextField(
        controller: tc,
        onTap: () async {
          TimeOfDay? time = await showTimePicker(
              context: context, initialTime: TimeOfDay.now());
          if (time != null) {
            DateTime dt =
                DateFormat.jm().parse(time.format(context).toString());
            tc.text = DateFormat("HH:mm:ss").format(dt);
          }
        },
        readOnly: true,
        decoration: InputDecoration(
            labelText: 'Enter time', suffixIcon: Icon(Icons.timer)),
      ),
    );
  }
}
