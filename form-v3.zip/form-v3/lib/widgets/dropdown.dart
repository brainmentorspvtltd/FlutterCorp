import 'package:flutter/material.dart';

import '/repository/dropdown_operations.dart';

class DropDown extends StatefulWidget {
  const DropDown({Key? key}) : super(key: key);

  @override
  State<DropDown> createState() => _DropDownState();
}

class _DropDownState extends State<DropDown> {
  List<String> cities = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    cities = DropDownOperations.getCityData();
  }

  String selectedCity = "Delhi";

  List<DropdownMenuItem<String>> _createItems() {
    return cities
        .map((String city) => DropdownMenuItem<String>(
              child: Text(city),
              value: city,
            ))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.all(15),
        child: DropdownButtonFormField<String>(
          value: selectedCity,
          items: _createItems(),
          dropdownColor: Colors.lightGreen,
          validator: (String? selectedValue) {
            return selectedValue == null ? "Select a City" : null;
          },
          decoration: InputDecoration(

              //filled: true,
              //fillColor: Colors.limeAccent,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide(color: Colors.green, width: 2))),
          onChanged: (String? value) {
            selectedCity = value!;
            setState(() {});
          },
        ));
  }
}
