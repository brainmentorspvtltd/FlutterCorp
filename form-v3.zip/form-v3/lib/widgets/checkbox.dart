import 'package:flutter/material.dart';

class CheckBox extends StatefulWidget {
  const CheckBox({Key? key}) : super(key: key);

  @override
  State<CheckBox> createState() => _CheckBoxState();
}

class _CheckBoxState extends State<CheckBox> {
  bool checkBoxValue = false;
  @override
  Widget build(BuildContext context) {
    return FormField(
        initialValue: checkBoxValue,
        validator: (bool? value) {
          if (value == null || value == false) {
            print("Inside the CheckBox Value $value");
            return "Tick the Conditions Checkbox";
          }
          value = checkBoxValue;

          return null;
        },
        builder: (FormFieldState<dynamic> field) {
          return CheckboxListTile(
              subtitle: Text(
                checkBoxValue == true ? "" : "Tick the Conditions Checkbox",
                style: TextStyle(color: Colors.red),
              ),
              activeColor: Colors.green,
              controlAffinity: ListTileControlAffinity.leading,
              title: Text('I Agree All the Conditions...'),
              value: checkBoxValue,
              onChanged: (bool? value) {
                checkBoxValue = value!;
                //checkBoxValue = !checkBoxValue;
                setState(() {});
              });
        });
  }
}
