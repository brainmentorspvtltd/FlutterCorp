import 'package:flutter/material.dart';

class Movie extends StatelessWidget {
  const Movie({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(
        child: Card(
          margin: EdgeInsets.all(10),
          shadowColor: Colors.green,
          elevation: 10,
          child: Column(children: [
            Stack(
              children: [
                Image.network(
                    'https://upload.wikimedia.org/wikipedia/en/2/23/Deadpool_%282016_poster%29.png')
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: [
                    Text(
                      'Dead pool'.toUpperCase(),
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    Row(
                      children: [Text("Hindi"), Text('  2D')],
                    )
                  ],
                ),
                ElevatedButton(
                  onPressed: () {},
                  child: Text('Book Now'),
                  style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.red)),
                )
              ],
            )
          ]),
        ),
      )
    ]);
  }
}
