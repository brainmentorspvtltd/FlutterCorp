import 'package:flutter/material.dart';
import 'package:movie_app/pages/movies.dart';

void main() {
  runApp(MaterialApp(
    home: Movies(),
  ));
}
