import 'package:dio/dio.dart';
import 'package:firebase_demo/utils/interceptor.dart';

class ApiClient {
  late Dio _dio;
  ApiClient() {
    BaseOptions options = BaseOptions(
        baseUrl: "https://newsapi.org/v2/top-headlines",
        connectTimeout: 7000,
        contentType: "application/json");
    _dio = Dio(options);
    _dio.interceptors.add(LoggingInterceptor());
    // _dio.options.connectTimeout = 6000;
  }
  Future<Map<String, dynamic>> get() async {
    String URL = "?country=us&apiKey=11f0dc28d8874be0bb82287cbcf26121";
    Response response = await _dio.get(URL);
    print(response.data);
    print(response.data.runtimeType);
    return response.data;
  }
}
