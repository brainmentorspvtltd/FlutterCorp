import 'package:firebase_demo/pages/api_consume.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: ApiConsume(),
  ));
}
