import 'package:dio/dio.dart';

class LoggingInterceptor extends Interceptor {
  @override
  void onRequest(RequestOptions opt, RequestInterceptorHandler handler) {
    Map<String, dynamic> h = {"AUTH": "A1111"};
    opt.headers.addAll(h);
    opt.connectTimeout = 4000;

    print("!!!!!!!!!!! REQ " + DateTime.now().toString());
    return super.onRequest(opt, handler);
  }

  @override
  void onResponse(Response opt, ResponseInterceptorHandler handler) {
    print("RES !!!!!!!!!!!!!! " + DateTime.now().toString());
    return super.onResponse(opt, handler);
  }

  void onError(DioError error, ErrorInterceptorHandler handler) {
    print(error.stackTrace);
    print(error.message);
  }
}
