import 'package:firebase_demo/models/news.dart';
import 'package:firebase_demo/services/api_client.dart';
import 'package:flutter/material.dart';

class ApiConsume extends StatefulWidget {
  const ApiConsume({Key? key}) : super(key: key);

  @override
  State<ApiConsume> createState() => _ApiConsumeState();
}

class _ApiConsumeState extends State<ApiConsume> {
  ApiClient _apiClient = ApiClient();
  Future<List<News>> _getNews() async {
    Map<String, dynamic> map = await _apiClient.get();
    print("***********************MAP is $map");
    List<dynamic> list = map["articles"];
    print("List is $list");
    List<News> newsList = list.map((element) {
      News news = News();
      news.author = element['author'] ?? "";
      news.title = element['title'] ?? "";
      news.urlToImage = element['urlToImage'] ?? "";
      return news;
    }).toList();
    print("######## News List is $newsList");
    return newsList;
  }

  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          ElevatedButton(
              onPressed: () {
                _getNews();
              },
              child: Text('Get the News Data')),
          Container(
            height: deviceSize.height * 0.90,
            child: FutureBuilder<List<News>>(
              future: _getNews(),
              builder: (_, AsyncSnapshot<List<News>> snapshot) {
                if (snapshot.hasData) {
                  return ListView.builder(
                    itemBuilder: (_, int index) {
                      return ListTile(
                        title: Text(snapshot.data![index].title),
                        leading:
                            Image.network(snapshot.data![index].urlToImage),
                        subtitle: Text(snapshot.data![index].author),
                      );
                    },
                    itemCount: snapshot.data?.length,
                  );
                } else if (snapshot.hasError) {
                  return Text('Some Error');
                } else {
                  return CircularProgressIndicator();
                }
              },
            ),
          )
        ]),
      ),
    );
  }
}
