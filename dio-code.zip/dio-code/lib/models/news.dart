class News {
  late String title;
  late String author;
  late String urlToImage;
  News() {
    title = "";
    author = "";
    urlToImage = "";
  }
}
