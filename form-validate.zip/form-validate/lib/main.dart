import 'package:flutter/material.dart';
import 'package:forms_demo/pages/register.dart';

void main() {
  runApp(MaterialApp(
    home: Register(),
  ));
}
