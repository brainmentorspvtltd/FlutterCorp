import 'package:flutter/material.dart';
import 'package:forms_demo/utils/validations.dart';
import 'package:forms_demo/widgets/form_field.dart';

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  Validation _validation = Validation();

  _submitForm() {
    var formState = formKey.currentState;
    if (formState != null && formState.validate()) {
      print("Form is Valid");
    } else {
      print("Form is Not valid");
    }
  }

  final formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text('Register'),
          centerTitle: true,
          leading: Icon(Icons.app_registration_rounded)),
      body: SafeArea(
          child: Form(
        autovalidateMode: AutovalidateMode.onUserInteraction,
        key: formKey,
        child: Column(
          children: [
            RegFormField(
              label: 'Email',
              validationFn: _validation.isCorrectEmail,
            ),
            RegFormField(
              label: 'Password',
              hideText: true,
              validationFn: (String str) {
                _validation.setMinLength(8);
                return _validation.isMin(str);
              },
            ),
            RegFormField(
              label: 'Name',
              validationFn: _validation.isValidName,
            ),
            ElevatedButton(
                onPressed: () {
                  _submitForm();
                },
                child: Text('Register'))
          ],
        ),
      )),
    );
  }
}
