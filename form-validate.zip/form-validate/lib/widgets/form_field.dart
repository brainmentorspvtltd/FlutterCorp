import 'package:flutter/material.dart';

class RegFormField extends StatelessWidget {
  String label;
  Function validationFn;
  bool hideText;
  RegFormField(
      {required this.label, required this.validationFn, this.hideText = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      child: TextFormField(
        obscureText: hideText,
        validator: (String? value) {
          if (validationFn(value)) {
            return null;
          } else {
            return "Invalid $label !";
          }
        },
        decoration: InputDecoration(
            hintText: 'Type $label',
            label: Text(label),
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
      ),
    );
  }
}
