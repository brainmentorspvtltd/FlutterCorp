class AppConstants {}

class RouteConstants {
  static String HOME = "/";
  static String DASHBOARD = "/dashboard";
}
