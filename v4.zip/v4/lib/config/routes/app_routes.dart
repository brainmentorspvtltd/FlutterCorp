import 'package:scalable_app/config/constants/application.dart';
import 'package:scalable_app/core/auth/login/presentation/pages/login.dart';
import 'package:scalable_app/core/auth/login/presentation/pages/notification.dart';
import 'package:scalable_app/features/dashboard/presentation/pages/camera_gallery.dart';
import 'package:scalable_app/features/dashboard/presentation/pages/dashboard.dart';
import 'package:scalable_app/features/dashboard/presentation/pages/stream_app.dart';

getRoutes() {
  return {
    //RouteConstants.HOME: (context) => NotificationPage(),
    RouteConstants.DASHBOARD: (context) => DashBoard(),
    RouteConstants.HOME: (context) => CameraAndGallery()
  };
}
