import 'package:json_annotation/json_annotation.dart';
part 'user.g.dart';

@JsonSerializable()
class User {
  late String userid;
  late String password;
  User() {}
  User.takeInput(this.userid, this.password);
  static UserFromJson(Map<String, dynamic> json) => _$UserFromJson(json);
  Map<String, dynamic> toJSON() => _$UserToJson(this);
}
