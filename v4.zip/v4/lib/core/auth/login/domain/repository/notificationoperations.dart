import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:scalable_app/config/constants/api_path.dart';
import 'package:scalable_app/core/auth/login/domain/models/notification.dart';
import 'package:scalable_app/shared/services/api_client.dart';
import 'dart:convert' as con;

class NotificationOperations {
  Future<Notification> getNotification() async {
    Response response = await ApiClient.getInstance()
        .get(dotenv.env[ApiPath.NOTIFICATION_KEY]!);
    print("DATA IS ...........");
    print(response.data); // data is a string
    // Convert string into object using dart:convert
    Notification nModel = Notification.fromJSON(con.jsonDecode(response.data));

    return nModel;
  }
}
