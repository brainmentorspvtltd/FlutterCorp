import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:scalable_app/core/auth/login/controllers/cubit/notification_state.dart';
import 'package:scalable_app/core/auth/login/domain/repository/notificationoperations.dart';

import '../../domain/models/notification.dart';
import 'package:get_it/get_it.dart';

class NotificationCubit extends Cubit<NotificationState> {
  final getIt = GetIt.instance;
  NotificationCubit() : super(NotificationState());

  getNotificationData() async {
    Notification notification =
        await getIt<NotificationOperations>().getNotification();
    var nf = NotificationState();
    // Get the response in Model and give to the State
    nf.id = notification.id;
    nf.appDate = notification.appDate;
    nf.appTime = notification.appTime;
    nf.connectionType = notification.connectionType;
    emit(nf); // Trigger BlocBuilder
  }
}
