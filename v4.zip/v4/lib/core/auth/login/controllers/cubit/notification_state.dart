class NotificationState {
  late String id;
  late String appDate;
  late String appTime;
  late String connectionType;
  NotificationState() {
    id = "";
    appDate = "";
    appTime = "";
    connectionType = "";
  }
}
