import 'package:flutter/material.dart';

class DropDown extends StatefulWidget {
  @override
  State<DropDown> createState() => _DropDownState();
}

class _DropDownState extends State<DropDown> {
  List<String> connectionTypes = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    connectionTypes = ["Permanent", "Temp"];
  }

  String selectedConnection = "Permanent";

  List<DropdownMenuItem<String>> _createItems() {
    return connectionTypes
        .map((String c) => DropdownMenuItem<String>(
              child: Text(c),
              value: c,
            ))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        //margin: EdgeInsets.all(15),
        child: DropdownButtonFormField<String>(
      onSaved: (String? value) {},
      value: selectedConnection,
      items: _createItems(),
      dropdownColor: Colors.white,
      validator: (String? selectedValue) {
        return selectedValue == null ? "Select a Connection Type" : null;
      },
      decoration: InputDecoration(

          //filled: true,
          //fillColor: Colors.limeAccent,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(20),
              borderSide: BorderSide(color: Colors.green, width: 2))),
      onChanged: (String? value) {
        selectedConnection = value!;
        setState(() {});
      },
    ));
  }
}
