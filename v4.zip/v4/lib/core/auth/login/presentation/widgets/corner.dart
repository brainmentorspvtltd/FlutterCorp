import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class WaveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    // TODO: implement getClip
    Path path = Path();
    path.lineTo(0, size.height - 50);
    path.quadraticBezierTo(
        0.2 * size.width, size.height, 0.60 * size.width, size.height - 100);
    path.lineTo(0.60 * size.width, size.height - 100);
    path.quadraticBezierTo(
        0.8 * size.width, size.height - 150, size.width, size.height - 150);
    path.lineTo(size.width, size.height - 50);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {
    // TODO: implement shouldReclip
    return false;
  }
}

class Corner extends StatelessWidget {
  double angle;
  Corner(this.angle);

  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    return Transform.rotate(
      angle: angle,
      child: ClipPath(
        clipper: WaveClipper(),
        child: Container(
          height: deviceSize.height / 3,
          width: deviceSize.width / 2,
          decoration: BoxDecoration(
              gradient: LinearGradient(colors: [Colors.orange, Colors.yellow])),
        ),
      ),
    );
  }
}
