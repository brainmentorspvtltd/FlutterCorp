import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:scalable_app/core/auth/login/controllers/cubit/notification_cubit.dart';
import 'package:scalable_app/core/auth/login/controllers/cubit/notification_state.dart';
import 'package:scalable_app/core/auth/login/presentation/widgets/box.dart';
import 'package:scalable_app/core/auth/login/presentation/widgets/datepicker.dart';
import 'package:scalable_app/core/auth/login/presentation/widgets/dropdown.dart';
import 'package:scalable_app/core/auth/login/presentation/widgets/textbox.dart';

class NotificationPage extends StatefulWidget {
  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  _loadData(ctx) {
    BlocProvider.of<NotificationCubit>(ctx).getNotificationData();
    //     .login(user.userid, user.password)
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _loadData(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Notification Details')),
      body: Container(
          child: Column(
        children: [
          BoxWidget(title: 'Notification Details', color: Colors.cyan),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                BlocBuilder<NotificationCubit, NotificationState>(
                  builder: (_, state) => TextBoxWidget(
                      labelName: 'Notification No', value: state.id),
                ),
                SizedBox(
                  width: 50,
                ),
                DatePickerWidget(
                  label: 'Appointment Date',
                )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: Container(
                    padding: EdgeInsets.all(20),
                    color: Colors.grey.shade400,
                    child: Text(
                      'Appointment Time',
                      style:
                          TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                SizedBox(
                  width: 30,
                ),
                Expanded(child: DropDown())
                // TextBoxWidget(
                //   readOnly: true,
                //   labelName: 'Appointment Time',
                // )
                // ElevatedButton(
                //     style: ButtonStyle(
                //         padding: MaterialStateProperty.all(EdgeInsets.all(20)),
                //         backgroundColor:
                //             MaterialStateProperty.all(Colors.grey)),
                //     onPressed: () {},
                //     child: Text('Appointment Time')),
              ],
            ),
          ),
          BoxWidget(title: 'Person Details', color: Colors.green)
        ],
      )),
    );
  }
}
