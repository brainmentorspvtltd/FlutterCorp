import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:scalable_app/config/constants/application.dart';
import 'package:scalable_app/core/auth/login/controllers/bloc/user_bloc.dart';
import 'package:scalable_app/core/auth/login/controllers/cubit/user.dart';
import 'package:scalable_app/core/auth/login/controllers/cubit/user_cubit.dart';
import 'package:scalable_app/core/auth/login/domain/models/user.dart';
import 'package:scalable_app/core/auth/login/domain/models/user_route_model.dart';
import 'package:scalable_app/core/auth/login/domain/repository/useroperations.dart';
import 'package:scalable_app/core/auth/login/presentation/widgets/corner.dart';
import 'package:scalable_app/core/auth/login/presentation/widgets/password.dart';
import 'package:scalable_app/core/auth/login/presentation/widgets/userid.dart';

class Login extends StatelessWidget {
  final getIt = GetIt.instance;

  @override
  Widget build(BuildContext context) {
    //UserOperations userOperations = UserOperations();
    TextEditingController useridCtrl = TextEditingController();
    TextEditingController passwordCtrl = TextEditingController();
    _logout() {
      var obj = UserLogOutEvent();
      obj.message = "Hi Logout Event";
      BlocProvider.of<UserBloc>(context).add(obj);
    }

    _login() async {
      User user = User();
      user.userid = useridCtrl.text;
      user.password = passwordCtrl.text;
      var obj = UserLoginEvent();
      obj.userid = user.userid;
      obj.password = user.password;
      BlocProvider.of<UserBloc>(context).add(obj);
      // BlocProvider.of<UserCubit>(context)
      //     .login(user.userid, user.password); // Call to the Cubit Login
      //User userObject = await getIt<UserOperations>().login(user);
      //User userObject = await userOperations.login(user);
      //Navigator.pushNamed(context, RouteConstants.DASHBOARD,
      //  arguments: {'userid': userObject.userid});
      //     Navigator.pushNamed(context, RouteConstants.DASHBOARD,
      //         arguments: UserRouteModel(userObject.userid, "2222"));
      // print("Login Response  ${userObject.userid} ${userObject.password}");
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
          child: Stack(
        children: [
          Positioned(child: Corner(150), left: 0, top: 0),
          Positioned(
            child: Corner(90),
            right: 0,
            bottom: 0,
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              BlocBuilder<UserBloc, UserState>(
                  builder: (_, state) => Text(
                        state.message,
                        style: TextStyle(color: Colors.white, fontSize: 20),
                      )),
              BlocBuilder<UserBloc, UserState>(
                  builder: (_, state) => Text(
                        state.message,
                        style: TextStyle(color: Colors.white, fontSize: 20),
                      )),
              Text(
                'Login',
                style: TextStyle(fontSize: 30, color: Colors.white),
              ),
              UserIdWidget(useridCtrl),
              PasswordWidget(passwordCtrl),
              ElevatedButton(
                  onPressed: () {
                    _login();
                  },
                  child: Text(
                    'Login',
                    style: TextStyle(fontSize: 20),
                  )),
              ElevatedButton(
                  onPressed: () {
                    _logout();
                  },
                  child: Text(
                    'Logout',
                    style: TextStyle(fontSize: 20),
                  ))
            ],
          )
        ],
      )),
    );
  }
}
