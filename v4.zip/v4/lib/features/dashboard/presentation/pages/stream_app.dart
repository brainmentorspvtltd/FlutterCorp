import 'package:flutter/material.dart';

Stream<int> createStream() {
  Stream<int> stream = Stream.periodic(Duration(seconds: 1), (int val) {
    return val;
  });
  return stream;
  print("Stream Created....");
  // stream.listen((event) {
  //   print("Listen $event");
  // });
}

class StreamConsumer extends StatelessWidget {
  const StreamConsumer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Stream Demo')),
      body: StreamBuilder(
          stream: createStream(),
          builder: (_, AsyncSnapshot<int> snapshot) {
            if (snapshot.hasError) {
              return Text('Some Error in Stream');
            } else {
              if (snapshot.data != null) {
                return Center(
                  child: Text(
                    snapshot.data.toString(),
                    style: TextStyle(fontSize: 30),
                  ),
                );
              } else {
                return Text('No Data');
              }
            }
          }),
    );
  }
}
