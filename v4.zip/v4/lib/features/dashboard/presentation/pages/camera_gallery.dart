import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';

class CameraAndGallery extends StatefulWidget {
  const CameraAndGallery({Key? key}) : super(key: key);

  @override
  State<CameraAndGallery> createState() => _CameraAndGalleryState();
}

class _CameraAndGalleryState extends State<CameraAndGallery> {
  String? imageFile;
  _openCamera([int ch = 1]) async {
    XFile? file = await im.pickImage(
        source: ch == 1 ? ImageSource.camera : ImageSource.gallery);
    imageFile = file?.path;
    setState(() {});
  }

  _showGPS() async {
    bool isEnabled = await Geolocator.isLocationServiceEnabled();
    if (isEnabled) {
      // check the Permission
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
        print("permission denied...");
      }
      if (perm == LocationPermission.deniedForever) {
        print("permission denied...");
      } else {
        Position pos = await Geolocator.getCurrentPosition();
        val = "Lat ${pos.latitude}  Lng ${pos.longitude}";
        setState(() {});
      }
    } else {
      print("Disabled Error");
    }
  }

  String val = "";
  ImagePicker im = ImagePicker();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Hardware Calls')),
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          imageFile != null
              ? Image.file(File(imageFile!))
              : Text(
                  'No Image',
                  style: TextStyle(fontSize: 30),
                ),
          Text(val, style: TextStyle(fontSize: 30)),
          ElevatedButton(
              onPressed: () {
                _showGPS();
              },
              child: Text('GPS')),
          ElevatedButton(
              onPressed: () {
                _openCamera();
              },
              child: Text('Camera')),
          ElevatedButton(
              onPressed: () {
                _openCamera(2);
              },
              child: Text('Gallery'))
        ]),
      ),
    );
  }
}
