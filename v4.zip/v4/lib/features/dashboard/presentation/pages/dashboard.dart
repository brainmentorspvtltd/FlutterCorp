import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:scalable_app/core/auth/login/domain/models/user_route_model.dart';

class DashBoard extends StatelessWidget {
  const DashBoard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // var args =
    //     ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>;
    var args = ModalRoute.of(context)?.settings.arguments as UserRouteModel;
    return Scaffold(
      appBar:
          // AppBar(title: Text('DashBoard ${args['userid']} ${args['phone']}')),
          AppBar(title: Text('DashBoard ${args.userid} ${args.phone}')),
    );
  }
}
