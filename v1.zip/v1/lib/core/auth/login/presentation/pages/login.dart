import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:scalable_app/core/auth/login/presentation/widgets/corner.dart';
import 'package:scalable_app/core/auth/login/presentation/widgets/password.dart';
import 'package:scalable_app/core/auth/login/presentation/widgets/userid.dart';

class Login extends StatelessWidget {
  const Login({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
          child: Stack(
        children: [
          Positioned(child: Corner(150), left: 0, top: 0),
          Positioned(
            child: Corner(90),
            right: 0,
            bottom: 0,
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Login',
                style: TextStyle(fontSize: 30, color: Colors.white),
              ),
              UserIdWidget(),
              PasswordWidget(),
              ElevatedButton(
                  onPressed: () {},
                  child: Text(
                    'Login',
                    style: TextStyle(fontSize: 20),
                  ))
            ],
          )
        ],
      )),
    );
  }
}
