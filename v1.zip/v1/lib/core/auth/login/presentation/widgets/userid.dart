import 'package:flutter/material.dart';

class UserIdWidget extends StatelessWidget {
  const UserIdWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(20),
      child: TextField(
          style: TextStyle(color: Colors.white, fontSize: 20),
          decoration: InputDecoration(
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                    color: Colors.tealAccent,
                    width: 2,
                    style: BorderStyle.solid),
                borderRadius: BorderRadius.circular(10),
              ),
              prefixIcon: Icon(
                Icons.person,
                color: Colors.yellow,
              ),
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              label: Text(
                'Userid',
                style: TextStyle(color: Colors.white),
              ),
              hintText: 'Type Userid Here',
              hintStyle: TextStyle(fontSize: 30, color: Colors.white))),
    );
  }
}
