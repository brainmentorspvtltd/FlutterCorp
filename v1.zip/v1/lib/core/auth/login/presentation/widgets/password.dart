import 'package:flutter/material.dart';

class PasswordWidget extends StatelessWidget {
  const PasswordWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(20),
      child: TextField(
          obscureText: true,
          style: TextStyle(color: Colors.white, fontSize: 20),
          decoration: InputDecoration(
              prefixIcon: Icon(
                Icons.password,
                color: Colors.yellow,
              ),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                    color: Colors.tealAccent,
                    width: 2,
                    style: BorderStyle.solid),
                borderRadius: BorderRadius.circular(10),
              ),
              label: Text(
                'Password',
                style: TextStyle(color: Colors.white),
              ),
              hintText: 'Type Password Here',
              hintStyle: TextStyle(fontSize: 30, color: Colors.white))),
    );
  }
}
