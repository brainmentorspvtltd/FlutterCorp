import 'package:flutter/material.dart';
import 'package:movie_app/widgets/vote.dart';

class Movie extends StatefulWidget {
  const Movie({Key? key}) : super(key: key);

  @override
  State<Movie> createState() => _MovieState();
}

class _MovieState extends State<Movie> {
  String message = "Book Now";
  _movieBook() {
    message = "Movie Booked";
    print("Clicked...");
    //setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    print("Build Called......");
    return Row(children: [
      Expanded(
        child: Card(
          margin: EdgeInsets.all(10),
          shadowColor: Colors.green,
          elevation: 10,
          child: Column(children: [
            Stack(
              children: [
                Image.network(
                    'https://upload.wikimedia.org/wikipedia/en/2/23/Deadpool_%282016_poster%29.png'),
                Positioned(
                  child: MovieVote(),
                  bottom: 10,
                  right: 10,
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: [
                    Text(
                      'Dead pool'.toUpperCase(),
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    Row(
                      children: [Text("Hindi"), Text('  2D')],
                    )
                  ],
                ),
                ElevatedButton(
                  onPressed: () {
                    _movieBook();
                  },
                  child: Text(message),
                  style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.red)),
                )
              ],
            )
          ]),
        ),
      )
    ]);
  }
}
