import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class MovieVote extends StatelessWidget {
  const MovieVote({Key? key}) : super(key: key);

  _getStyle({double fontSize = 20}) {
    return TextStyle(fontSize: fontSize, color: Colors.white);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: [
          Row(
            children: [
              IconButton(
                  onPressed: () {},
                  icon: FaIcon(
                    FontAwesomeIcons.heart,
                    color: Colors.redAccent,
                  )),
              Text(
                '100%',
                style: _getStyle(),
              ),
            ],
          ),
          Text(
            '1200 Votes',
            style: _getStyle(fontSize: 12),
          ),
        ],
      ),
      decoration: BoxDecoration(color: Colors.black),
    );
  }
}
