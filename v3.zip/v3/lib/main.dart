import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:get_it/get_it.dart';
import 'package:scalable_app/config/constants/application.dart';
import 'package:scalable_app/core/auth/login/controllers/bloc/user_bloc.dart';
import '/config/routes/app_routes.dart';
import '/core/auth/login/presentation/pages/login.dart';
import 'core/auth/login/controllers/cubit/user_cubit.dart';
import 'core/auth/login/domain/repository/useroperations.dart';

final getIt = GetIt.instance;
void main() async {
  await dotenv.load(fileName: ".env"); // Env Load
  setup();
  runApp(BlocProvider<UserBloc>(
      create: (_) => UserBloc(),
      child: MaterialApp(
        //home: Login(),
        routes: getRoutes(),
        initialRoute: RouteConstants.LOGIN,
      )));
}

void setup() {
  getIt.registerSingleton<UserOperations>(UserOperations());
}
