import 'package:scalable_app/config/constants/application.dart';
import 'package:scalable_app/core/auth/login/presentation/pages/login.dart';
import 'package:scalable_app/features/dashboard/presentation/pages/dashboard.dart';

getRoutes() {
  return {
    RouteConstants.LOGIN: (context) => Login(),
    RouteConstants.DASHBOARD: (context) => DashBoard()
  };
}
