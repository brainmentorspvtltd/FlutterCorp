// Singleton class -

import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import '/config/constants/api_path.dart';

class ApiClient {
  static ApiClient _apiClient = ApiClient._();
  Dio dio = Dio();
  ApiClient._() {}
  static ApiClient getInstance() {
    return _apiClient;
  }

  post(Map<String, dynamic> map) async {
    String URL = dotenv.env[ApiPath.LOGIN_URL_KEY]!;
    //dio.post(URL,data: );
    Response response = await dio.post(URL, data: map);
    return response;
  }

  get() {}
}
