import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:scalable_app/core/auth/login/controllers/cubit/user.dart';

import '../../domain/models/user.dart';
import '../../domain/repository/useroperations.dart';

class UserEvent {
  late String userid;
  late String password;
  UserEvent() {
    userid = "";
    password = "";
  }
}

class UserLoginEvent extends UserEvent {
  late String userid;
  late String password;
  UserLoginEvent() {
    userid = "";
    password = "";
  }
}

class UserLogOutEvent extends UserEvent {
  String message = "";
}

class UserBloc extends Bloc<UserEvent, UserState> {
  final getIt = GetIt.instance;
  UserBloc() : super(UserState()) {
    on<UserLoginEvent>(eventCall); // Inside Constructor Register an Event
    on<UserLogOutEvent>(eventCall2);
  }
  eventCall2(UserLogOutEvent evt, Emitter<UserState> emit) {
    emit(UserState.takeUser("", "", evt.message));
  }

  eventCall(UserLoginEvent event, Emitter<UserState> emit) async {
    User user = User();
    user.userid = event!.userid;
    user.password = event!.password;
    String message = "";
    User userObject = await getIt<UserOperations>().login(user);
    UserState userState = UserState();
    if (userObject.userid.length > 0 && userObject.password.length > 0) {
      message = "Welcome User";
    } else {
      message = "Invalid User";
    }
    return emit(
        UserState.takeUser(userObject.userid, userObject.password, message));
  }
}
