class UserRouteModel {
  String userid;
  String phone;
  UserRouteModel(this.userid, this.phone);
}
