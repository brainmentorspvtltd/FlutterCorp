abstract class Person {
  /*
  abstract it is a keyword, prevent object creation, only use through Inheritance
  Abstract class to create most generic project / common features
  */
  late int age;
  late String name;
  late String city;
  Person() {
    age = 0;
    name = "";
    city = "";
    print("I am a Person Default Constructor");
  }
  Person.takeInput(this.name, this.age, this.city);
  // Person.takeInput(String name, int age, String city) {
  //   this.name = name;
  //   this.age = age;
  //   this.city = city;
  //   print("I am in Person takeInput Named Constructor....");
  // }
  void show() {
    print("Name $name Age $age City $city");
  }

  void printICard(); // treat like abstract method
  // force child to override it
}

// extends Inherit
class Student extends Person {
  late String course;
  late int duration;
  // super() - call default constructor of parent , Implicit call
  //Student() : super() {  // super is a keyword , access parent things
  Student() {
    // Child Class default call parent class default by default
    course = "";
    duration = 0;
    print("I am a Student Default Constructor");
  }
  // Student.takeData(this.course, this.duration);
//  Student.takeData(String course, int duration) : super() {
  // Constructor Chaining
  Student.takeData(this.course, this.duration, int id, String name, String city)
      : super.takeInput(name, id, city);
  // Student.takeData(
  //     String course, int duration, int id, String name, String city)
  //     : super.takeInput(name, id, city) {
  //   this.course = course;
  //   this.duration = duration;
  //   print("Calling Student class NAmed Constructor....");
  // }
  @override
  void show() {
    super.show(); // Calling Parent Show
    print("Course $course Duration $duration");
  }

  @override
  void printICard() {
    print("Student I Card");
  }
}

void main() {
  // Student ram = Student(); // Calling Default Constructor
  Student ram = Student.takeData("Dart", 2, 1001, "Ram", "Delhi");
  ram.show();
  ram.printICard();
}
