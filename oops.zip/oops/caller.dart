import 'dart:io';

import 'emp.dart';

void main() {
  // Employee ram = Employee(); // Object Construct (new optional)
  // During Object Construction it internally call unamed constructor

  // console user input
  print("Enter the Id ");
  String value = stdin.readLineSync() ?? "0"; // Null Aware Operator
  int id = int.parse(value);
  print("Enter the Name");
  String name = stdin.readLineSync()!; // Bang Operator !
  // print("Enter the Salary");
  // double? salary = double.parse(stdin.readLineSync()!);

  Employee ram =
      Employee.takeInput(id, name, null); // Calling Named Constructor
  // ram._id = -1002; // Class Member Variables never be exposed
  //ram.name = "Ram Kumar"; // Setters
  //ram.salary = 90000.20;
  ram.printDetails();
  // print(ram.id);
  // print(ram.name);
  // print(ram.salary);
}
