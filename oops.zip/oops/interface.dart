abstract class DB {
  create();
  update();
  remove();
  read();
}
// interface - What to do? - Standards , Prototype, Guidelines

abstract class Network {
  online();
  offline();
}

// How to do
class MySql implements DB, Network {
  @override
  create() {
    // TODO: implement create
    throw UnimplementedError();
  }

  @override
  read() {
    // TODO: implement read
    throw UnimplementedError();
  }

  @override
  remove() {
    // TODO: implement remove
    throw UnimplementedError();
  }

  @override
  update() {
    // TODO: implement update
    throw UnimplementedError();
  }

  @override
  offline() {
    // TODO: implement offline
    throw UnimplementedError();
  }

  @override
  online() {
    // TODO: implement online
    throw UnimplementedError();
  }
}
