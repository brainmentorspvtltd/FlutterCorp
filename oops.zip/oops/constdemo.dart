void main() {
  // Compile time constants
  const MAX = 100; // Compile time allocation
  //MAX = 200;
  //MAX++;
  const int MIN = 1;
  // Runtime Constants
  final StringBuffer sb = new StringBuffer(); // Runtime Memory Allocation
  // Object Creation
  // final intialize inside the constructor
  T obj = T(10,
      20); // Constructor is call one time for one object (Intialize one time)
}

class T {
  final int a;
  final int b;
  // const constructor which is used to intialize the final things
  // one time intialize
  const T(this.a, this.b); // Shortcut way of writing constructor

  // void plus() {
  //   this.a++; // ReInitalize (Error)
  //   this.b++;
  // }
}
