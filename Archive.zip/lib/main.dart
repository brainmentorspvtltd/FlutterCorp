import 'package:flutter/material.dart';

void main() {
  const String imageURL = "https://servicesdown.in/img/foodpanda-logo.png";
  runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        drawer: Drawer(
          elevation: 10,
          child: SafeArea(
            child: Column(
              children: [
                UserAccountsDrawerHeader(
                  accountEmail: Text('amit@gmail.com'),
                  accountName: Text('Amit Srivastava'),
                ),
                Text('110007'),
                Text(
                  'India',
                  style: TextStyle(fontSize: 20),
                ),
              ],
            ),
          ),
          backgroundColor: Colors.amberAccent,
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.endTop,
        floatingActionButton: FloatingActionButton(
          backgroundColor: Colors.pinkAccent,
          onPressed: () {},
          child: Icon(
            Icons.phone,
            color: Colors.black,
          ),
        ),
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(120),
          child: AppBar(
            actions: [Icon(Icons.more_vert)],
            shadowColor: Colors.redAccent,
            elevation: 0,
            title: Image.network(imageURL),
            // title: Text(
            //   'My App Bar',
            //   style: TextStyle(color: Colors.cyan),
            // ),
            backgroundColor: Color.fromARGB(255, 4, 80, 62),
            //leading: Icon(Icons.menu),
          ),
        ),
      )));
  //SafeArea(
  //  child: Text('Hello Flutter')))); // to place the widget on top
}
