class Employee {
  late int _id; // They come in the memory when instance/ object is created
  late String _name;
  late double _salary;

  int get id => _id;
  get name => this._name;

  set name(value) => this._name = value;

  get salary => this._salary;

  set salary(value) => this._salary = value; // _ make private
  // private scope is with in the file / library
  // Unamed Constructor
  // To initalize the values of member variables (Instance Variables)
  // No Parameter Constructor
  Employee() {
    print("Unnamed Cons Call");
    _id = 0;
    _name = "";
    _salary = 0.0;
  }
  // Named Constructor
  /* Employee.takeInput(int id, String name, double salary) {
    // Local Variables
    //this; // this is a keyword , and it hold the
    // reference / address of the current calling object
    // Instance Variable = Local Variable
    // this.id = id;
    // this.name = name;
    // this.salary = salary;
    _id = id;
    _name = name;
    _salary = salary;
  }*/

  // Constructor ShortHand
  Employee.takeInput(this._id, this._name, this._salary);

  // set name(String name) => _name = name;
  // String get name => _name;

  // int get id => _id;

  void printDetails() {
    print("Id $_id");
    print("Name $_name");
    print("Salary $_salary");
  }
}
