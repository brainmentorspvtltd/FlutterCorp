import 'emp.dart';

void main() {
  // Employee ram = Employee(); // Object Construct (new optional)
  // During Object Construction it internally call unamed constructor
  Employee ram =
      Employee.takeInput(1001, "Ram", 2222); // Calling Named Constructor
  // ram._id = -1002; // Class Member Variables never be exposed
  ram.name = "Ram Kumar";
  ram.salary = 90000.20;
  ram.printDetails();
  // print(ram.id);
  // print(ram.name);
  // print(ram.salary);
}
