void main() {
  // print(add(10, 20));
  // print(add());
  // print(add(10));

  print(add(y: 20, x: 10));
  print(add());
  print(add(y: 10));
  print(add(x: 10));
  paymentDetail(
      paymentId: 1001,
      orderId: 1,
      currency: 'INR',
      phone: "11111",
      email: "a@a.com",
      userName: 'A',
      city: 'Mumbai');
}

void paymentDetail(
    {required String userName,
    required int orderId,
    required String currency,
    required int paymentId,
    required String email,
    required String phone,
    String city = "delhi",
    String country = "India"}) {}

int add2([int x = 0, int y = 0]) {
  return x + y;
}

adder(var x, var y) {
  return x + y;
}

int add({int x = 0, int y = 0}) {
  return x + y;
}
