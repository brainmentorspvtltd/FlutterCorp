void main() {
  int age = 21;
  double salary = 9000.20;
  bool att = true;
  var age2 = 22;
  dynamic t = 100;
  t = true;
  String name = "Amit";
  name = 'Amit';
  String msg = "hgdkjfhgdf "
      "hgkdjhgf "
      " ghdfghdkfjhgkdjfgkjdhfgkjh";
  print(msg);
  // String msg2 = """ gklfdjklgjfdklgjdflkjg
  // 4fhjkhfgk
  // fjkhjfglhfgjllh
  // jflkhjflgkj
  // hjfgkhg""";
  // String msg2 = ''' gfdkjhgkfjdhgjkd
  // fjhkjhgk
  // fggjgkjfh
  // fjhkf''';
  var msg2 = '''jdfjgfl
  \t hjfglkh
  hjfglkh
  hfgjhlfkg''';
  print(msg2);
  print(msg2[0]);
  print(msg.toUpperCase());
  print(msg.codeUnitAt(0)); // Ascii Code
  print(msg.codeUnits); // All character ASCII Code
  print(msg2.runtimeType);
  print(msg2 is String);
  print(msg2.substring(2, 6)); // 2, 5
  print(msg2.length);
  print(msg2.isEmpty);
  String q = age.toString();
  double e1 = age.toDouble();
  String bonus = "20000";
  int d = int.parse(bonus); // String to int convert
  double g1 = double.parse("999.222");
}
