void main() {
  int e = 100; // Statisically Typed
  var f = 200; // Type Inference
  const int g = 200;
  //g = 900;
  const r = 200; // Constant
  var h; // dynamic h;
  h = 10;
  h = true;
  dynamic ww = 999;
  ww = "fjkdfg";
}
