void main() {
  //List<dynamic> prices = [90,"ten", true];
  //var prices = [90, "ten", true];
  List<int> list = [100, 200, 300, 400, 500, 100, 200];
  list.add(888);
  list.insert(1, 2222);
  list.removeAt(0);
  list[0] = 222222;
  print(list);

  Set<int> set = {100, 200, 100, 200, 100, 888}; // No Duplicate
  var set2 = {100, 200, 100, 10, 100, 100};
  print(set2);

  Map<String, int> prices = {"mobile": 10000, "tablet": 8000, "watch": 2000};
  print(prices["mobile"]);
}
