void main() {
  final cube = (num) => num * num * num;
  final evenOdd = (num) => num % 2 == 0 ? "Even No $num" : "Odd No $num";
  loop(cube); // Loop Fn take another function as an argument
  // we pass the cube function as an argument pass we r not calling it.
  loop(evenOdd);
}

loop(Function callbackFn) {
  for (int i = 1; i <= 10; i++) {
    print(callbackFn(i));
  }
}

// 1 to 100 even odd
// 1 to 100 cube
// 1 to 100 prime number