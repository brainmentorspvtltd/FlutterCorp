import 'functions.dart';

void main() {
  // int result = add(x: 10, y: 20);
  // print("Result $result");
  Function fn = (int x, int y) {
    return x + y;
  };
  var fn2 = (a, b) {
    return a + b;
  };
  print(fn2(100, 200));

  // Fat Arrow Fn (One Line Code)
  final fn3 = (int a, int b) => a + b;
  print(fn3(10000, 20000));
}
