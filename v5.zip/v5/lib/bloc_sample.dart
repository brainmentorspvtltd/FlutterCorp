import 'dart:async';

void main() {
  Stream<int> s = streamIt();
  StreamSubscription sub = s.listen((event) {
    print(event);
  });
  Future.delayed(Duration(seconds: 10), () {
    sub.cancel();
  });
}

Stream<int> streamIt() async* {
  for (int i = 1; i <= 10; i++) {
    await Future.delayed(Duration(seconds: 3));
    yield i;
  }
}
