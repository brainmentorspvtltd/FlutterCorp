class AppConstants {}

class RouteConstants {
  static final String HOME = "/";
  static final String DASHBOARD = "/dashboard";
}
