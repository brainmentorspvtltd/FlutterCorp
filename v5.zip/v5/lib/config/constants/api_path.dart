class ApiPath {
  static String LOGIN_URL_KEY = "loginurl";
  static String NOTIFICATION_KEY = "notificationurl";
}
