import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import '/config/constants/application.dart';
import 'package:scalable_app/core/auth/login/presentation/pages/login.dart';
import 'package:scalable_app/core/auth/login/presentation/pages/notification.dart';
import 'package:scalable_app/features/dashboard/presentation/pages/camera_gallery.dart';
import 'package:scalable_app/features/dashboard/presentation/pages/dashboard.dart';
import 'package:scalable_app/features/dashboard/presentation/pages/stream_app.dart';

// Named Routes
// getRoutes() {
//   return {
//     //RouteConstants.HOME: (context) => NotificationPage(),
//     RouteConstants.DASHBOARD: (context) => DashBoard(),
//     RouteConstants.HOME: (context) => CameraAndGallery()
//   };
// }
Route onGeneratedRoute(RouteSettings routeSettings) {
  switch (routeSettings.name) {
    case "/":
      return MaterialPageRoute(builder: (_) => NotificationPage());
      break;
    case "/dashboard":
      return MaterialPageRoute(builder: (_) => DashBoard());
    default:
      return MaterialPageRoute(builder: (_) => DashBoard());
  }
}
