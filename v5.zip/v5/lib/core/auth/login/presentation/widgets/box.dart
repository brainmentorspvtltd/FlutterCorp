import 'package:flutter/material.dart';

class BoxWidget extends StatelessWidget {
  String title;
  Color color;
  BoxWidget({required this.title, required this.color});

  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    return Container(
        margin: EdgeInsets.all(10),
        width: deviceSize.width,
        padding: EdgeInsets.only(left: 20, top: 10, bottom: 10),
        color: color,
        child: Text(
          title,
          style: TextStyle(fontSize: 20, color: Colors.white),
        ));
  }
}
