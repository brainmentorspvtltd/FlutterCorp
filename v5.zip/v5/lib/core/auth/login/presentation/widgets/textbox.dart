import 'package:flutter/material.dart';

class TextBoxWidget extends StatelessWidget {
  String labelName;
  bool readOnly;
  String value;
  TextEditingController tc = TextEditingController();
  TextBoxWidget(
      {required this.labelName, this.readOnly = false, this.value = ""});

  @override
  Widget build(BuildContext context) {
    tc.text =
        value; // Value comes through BlocBuilder is set in TextEditingController
    print("Data is $value");
    return Expanded(
      child: Container(
        color: readOnly ? Colors.grey : Colors.transparent,
        child: TextField(
          controller: tc,
          readOnly: readOnly,
          decoration: InputDecoration(
              label: Text(
                labelName,
                style: TextStyle(
                    fontSize: 12,
                    color: Colors.black,
                    fontWeight: FontWeight.bold),
              ),
              border: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: Colors.grey, width: 2, style: BorderStyle.solid))),
        ),
      ),
    );
  }
}
