import 'package:flutter/material.dart';

class DatePickerWidget extends StatefulWidget {
  String label;
  DatePickerWidget({required this.label});
  @override
  State<DatePickerWidget> createState() => _DatePickerWidgetState();
}

class _DatePickerWidgetState extends State<DatePickerWidget> {
  TextEditingController tc = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.all(10),
        child: TextField(
          controller: tc,
          onTap: () async {
            DateTime? dateTime = await showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime(1990),
                lastDate: DateTime(2050));
            tc.text = dateTime!.toString();
          },
          decoration: InputDecoration(
              label: Text(
                widget.label,
                style: TextStyle(
                    fontSize: 12,
                    color: Colors.black,
                    fontWeight: FontWeight.bold),
              ),
              border: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: Colors.grey, width: 2, style: BorderStyle.solid))),
        ),
      ),
    );
  }
}
