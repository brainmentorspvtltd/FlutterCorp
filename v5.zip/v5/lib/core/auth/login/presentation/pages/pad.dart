import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_signature_pad/flutter_signature_pad.dart';
import 'dart:ui' as ui;

class Pad extends StatefulWidget {
  const Pad({Key? key}) : super(key: key);

  @override
  State<Pad> createState() => _PadState();
}

class _PadState extends State<Pad> {
  final _sign = GlobalKey<SignatureState>();
  ByteData _img = ByteData(0);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Column(
        children: [
          Container(
              height: 400,
              child: Signature(
                color: Colors.black, // Color of the drawing path
                strokeWidth: 5.0, // with
                backgroundPainter:
                    null, // Additional custom painter to draw stuff like watermark
                onSign: null, // Callback called on user pan drawing
                key:
                    _sign, // key that allow you to provide a GlobalKey that'll let you retrieve the image once user has signed
              )),
          MaterialButton(
              color: Colors.green,
              onPressed: () async {
                final sign = _sign.currentState;
                //retrieve image data, do whatever you want with it (send to server, save locally...)
                final image = await sign?.getData();
                var data =
                    await image?.toByteData(format: ui.ImageByteFormat.png);
                sign?.clear();
                final encoded = base64.encode(data!.buffer.asUint8List());
                setState(() {
                  _img = data;
                });
                debugPrint("onPressed " + encoded);
              },
              child: Text("Save"))
        ],
      )),
    );
  }
}
