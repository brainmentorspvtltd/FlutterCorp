import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import '/core/auth/login/domain/models/user.dart';

import '../../domain/repository/useroperations.dart';
import 'user.dart';

class UserCubit extends Cubit<UserState> {
  final getIt = GetIt.instance;
  UserCubit() : super(UserState());
  void login(String userid, String password) async {
    User user = User();
    user.userid = userid;
    user.password = password;
    String message = "";
    User userObject = await getIt<UserOperations>().login(user);
    UserState userState = UserState();
    if (userObject.userid.length > 0 && userObject.password.length > 0) {
      message = "Welcome User";
    } else {
      message = "Invalid User";
    }
    emit(UserState.takeUser(userObject.userid, userObject.password,
        message)); // fire the event and it get stream
  }
}
