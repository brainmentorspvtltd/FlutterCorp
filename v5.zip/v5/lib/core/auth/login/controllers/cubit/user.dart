// Represent a User State
class UserState {
  late String userid;
  late String password;
  late String message;
  UserState() {
    userid = "";
    password = "";
    message = "";
  }
  UserState.takeUser(this.userid, this.password, this.message);
}
