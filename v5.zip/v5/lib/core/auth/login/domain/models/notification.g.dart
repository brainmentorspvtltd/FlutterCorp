// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'notification.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Notification _$NotificationFromJson(Map<String, dynamic> json) => Notification()
  ..id = json['id'] as String
  ..appDate = json['appDate'] as String
  ..appTime = json['appTime'] as String
  ..connectionType = json['connectionType'] as String;

Map<String, dynamic> _$NotificationToJson(Notification instance) =>
    <String, dynamic>{
      'id': instance.id,
      'appDate': instance.appDate,
      'appTime': instance.appTime,
      'connectionType': instance.connectionType,
    };
