import 'package:json_annotation/json_annotation.dart';
part 'notification.g.dart';

@JsonSerializable()
class Notification {
  late String id;
  late String appDate;
  late String appTime;
  late String connectionType;
  Notification() {
    id = "";
    appDate = "";
    appTime = "";
    connectionType = "";
  }

  static fromJSON(Map<String, dynamic> json) => _$NotificationFromJson(json);

  toJSON() => _$NotificationToJson(this);
}
