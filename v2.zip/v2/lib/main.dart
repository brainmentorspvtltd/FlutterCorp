import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:get_it/get_it.dart';
import 'package:scalable_app/config/constants/application.dart';
import '/config/routes/app_routes.dart';
import '/core/auth/login/presentation/pages/login.dart';
import 'core/auth/login/domain/repository/useroperations.dart';

final getIt = GetIt.instance;
void main() async {
  await dotenv.load(fileName: ".env"); // Env Load
  setup();
  runApp(MaterialApp(
    //home: Login(),
    routes: getRoutes(),
    initialRoute: RouteConstants.LOGIN,
  ));
}

void setup() {
  getIt.registerSingleton<UserOperations>(UserOperations());
}
