class AppConstants {}

class RouteConstants {
  static String LOGIN = "/";
  static String DASHBOARD = "/dashboard";
}
