class ApiPath {
  static String LOGIN_URL_KEY = "loginurl";
}
