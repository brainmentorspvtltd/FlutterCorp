import 'package:dio/dio.dart';

import '../../../../../shared/services/api_client.dart';
import '../models/user.dart';

class UserOperations {
  ApiClient apiClient = ApiClient.getInstance();
  login(User user) async {
    Response response = await apiClient.post(user.toJSON());
    User userObject = User.UserFromJson(response.data);
    return userObject;
  }
}
