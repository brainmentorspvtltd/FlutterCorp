import 'package:hive/hive.dart';
part 'person.g.dart';

@HiveType(typeId: 1)
class Person {
  @HiveField(0)
  late String email;
  @HiveField(1)
  late String password;
  @HiveField(2)
  late String name;
  @HiveField(3)
  late String city;
  // late bool status;
  // late int gender;
  // late String date;
  // late String time;
  // late int startRange;
  // late int endRange;

  Person() {}

// Manual
  // Map<String, dynamic> toMap() {
  //   return {"name": name, "email": email, "city": city};
  // }
}
