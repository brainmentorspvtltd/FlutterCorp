class User {
  late String userid;
  late String password;
  User(this.userid, this.password);
  // Manual

  // Auto Generated
  Map<String, dynamic> toJSON() {
    return {"userid": userid, "password": password};
  }

  static fromJSON(Map<String, dynamic> map) {
    return User(map["userid"], map["password"]);
  }
}
