import 'package:flutter/material.dart';
import 'package:flutter_form_handling/pages/apicall_screen.dart';
import 'package:flutter_form_handling/pages/viewall.dart';
import 'package:flutter_form_handling/repository/offline.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '/pages/register.dart';
import 'models/person.dart';
import 'pages/mainscreen.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

void main() async {
  // Load the Env File
  await dotenv.load(fileName: ".env");
  // Step-1 Initalize the Hive
  await Hive.initFlutter();
  Hive.registerAdapter(PersonAdapter());
  // Pre Load the Box
  Box box = await Hive.openBox("person");
  Offline.box = box;

  //runApp(MaterialApp(home: Register()));
  //runApp(MaterialApp(home: MainScreen()));
  runApp(MaterialApp(
    home: ApiCallScreen(),
  ));
}
