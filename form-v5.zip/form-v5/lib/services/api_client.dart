import 'package:flutter_form_handling/utils/constants.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';

class ApiClient {
  static ApiClient _client = ApiClient._();
  ApiClient._() {}
  static ApiClient getInstance() {
    return _client;
  }

  Future<http.Response> get() {
    Uri url = Uri.parse(dotenv.env[Constants.URL]!);
    Future<http.Response> future = http.get(url);
    // headers: {"Content-Type":"application/json", "timeout":"6"});
    return future;
  }

  post() {
    Uri url = Uri.parse('');
    Future<http.Response> future = http.post(url, body: {"name": "amit"});
    return future;
  }
}
