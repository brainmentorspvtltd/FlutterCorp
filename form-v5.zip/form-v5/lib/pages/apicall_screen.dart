import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_form_handling/services/api_client.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

class ApiCallScreen extends StatefulWidget {
  const ApiCallScreen({Key? key}) : super(key: key);

  @override
  State<ApiCallScreen> createState() => _ApiCallScreenState();
}

class _ApiCallScreenState extends State<ApiCallScreen> {
  String data = "";
  ApiClient _apiClient = ApiClient.getInstance();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getResponse();
  }

  getResponse() {
    Future<http.Response> future = _apiClient.get();
    future.then((http.Response response) {
      String json = response.body;
      //Map<String, dynamic> map = convert.jsonDecode(json);
      List<dynamic> list = convert.jsonDecode(json);
      print(list);
      // data = map["data"][0]['images']['original']['url'];
      data = list[0]['fieldname'];
      setState(() {});
    }).catchError((err) => print("error is $err"));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
            child: data.length == 0
                ? Center(
                    child: CircularProgressIndicator(),
                  )
                : Text(data))
        // : Image.network(data)),
        );
  }
}
