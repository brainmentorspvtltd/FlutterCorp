import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_handling/repository/offline.dart';
import 'package:flutter_form_handling/utils/toast.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/person.dart';
import '/widgets/slider.dart';
import '/widgets/timepicker.dart';
import '/widgets/datepicker.dart';

import '/utils/validations.dart';
import '/widgets/dropdown.dart';
import '/widgets/checkbox.dart';
import '/widgets/textbox.dart';
import '/widgets/radio.dart' as radio;

class Register extends StatefulWidget {
  //late Box box;

  // Register(this.box);
  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final formKey = GlobalKey<FormState>();
  late Offline _offline = Offline();
  @override
  void initState() {
    super.initState();
    //_offline = Offline(widget.box);
    Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
      if (result == ConnectivityResult.wifi ||
          result == ConnectivityResult.mobile) {
        showToast("U r Online");
        // Online / Cloud Store
      } else if (result == ConnectivityResult.none) {
        showToast("U r OffLine");
        _offline.openBox("person");
        // Local Store
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
    //_offline.closeBox();
    // Close all Boxes
    //Hive.close();
  }

  _submitForm() async {
    print("Form Submit....");
    var formState = formKey.currentState;
    if (formState != null && formState.validate()) {
      print("Form is Valid ");
      formState.save(); // call onSaved function --> fill Model value
      print(
          "Model Data is ${person.email} ${person.name} ${person.password} ${person.city}");
      String result = await _offline.addPerson(person);
      showToast(result);
    } else {
      print("Form is Not Valid");
    }
  }

  Person person = Person();
  String emailError = "";
  String passwordError = "";
  String nameError = "";

  _emailValidationOnChange(String value) {
    emailError = Validation.isCorrectEmail(value) ?? "";
    setState(() {});
  }

  _passwordValidationOnChange(String value) {
    passwordError = Validation.isCorrectPassword(value) ?? "";
    setState(() {});
  }

  _nameValidationOnChange(String value) {
    nameError = Validation.isCorrectName(value) ?? "";
    setState(() {});
  }

  bool checkboxValue = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Register Form'),
        centerTitle: true,
        backgroundColor: Colors.redAccent,
      ),
      body: SingleChildScrollView(
        child: Form(
          //autovalidateMode: AutovalidateMode.always,
          key: formKey,
          child: Column(children: [
            TextBox(
              model: person,
              errorMessage: emailError,
              validationOnChange: _emailValidationOnChange,
              validationFn: Validation.isCorrectEmail,
              label: 'Email',
              iconData: Icons.email,
            ),
            TextBox(
              model: person,
              hideText: true,
              errorMessage: passwordError,
              validationOnChange: _passwordValidationOnChange,
              validationFn: Validation.isCorrectPassword,
              label: 'Password',
              iconData: Icons.password,
            ),
            TextBox(
              model: person,
              errorMessage: nameError,
              validationOnChange: _nameValidationOnChange,
              validationFn: Validation.isCorrectName,
              label: 'Name',
              iconData: Icons.verified_user,
            ),
            DropDown(
              model: person,
            ),
            CheckBox(),
            radio.Radio(),
            CustomDatePicker(),
            CustomTimePicker(),
            CustomSlider(),
            ElevatedButton(
              onPressed: () {
                _submitForm();
              },
              child: Text(
                'Register',
                style: TextStyle(fontSize: 20),
              ),
              style: ButtonStyle(
                  padding:
                      MaterialStateProperty.resolveWith<EdgeInsetsGeometry>(
                    (Set<MaterialState> states) {
                      return EdgeInsets.all(20);
                    },
                  ),
                  backgroundColor:
                      MaterialStateProperty.all(Colors.green.shade600)),
            )
          ]),
        ),
      ),
    );
  }
}
