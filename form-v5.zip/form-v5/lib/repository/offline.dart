import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../models/person.dart';

class Offline {
  // CRUD
  static late Box box;
  //Box? box; //might be null
  // Offline(Box box) {
  //   // this.box = box;
  //   //openBox('personbox');
  // }
  openBox(String boxName) async {
    box = await Hive.openBox(boxName);
    // return null;
    // return Future<null>
  }

  closeBox() {
    box.close();
  }

  ValueListenable<Box> readAll() {
    return box.listenable();
  }

  Future<String> addPerson(Person person) async {
    try {
      await box.add(person);
      return "Record is Added";
    } catch (err) {
      print("Error During Add $err");
    }
    return "Error During Add";
  }
}
