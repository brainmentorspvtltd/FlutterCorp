class Constants {
  Constants._() {}
  static String URL = "url";
}
